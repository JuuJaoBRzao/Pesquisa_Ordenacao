package controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import model.Buscador;
import model.Ordenador;
import model.Produto;
import util.Utilidades;

public class Controller {

    private static final int REPETICOES = 1000;
    private static final long LIMITE_2MIN = 120L * 1000000000L;

    private ArrayList<Produto> lista = new ArrayList<Produto>();
    private ArrayList<Produto> listaPorId = new ArrayList<Produto>(); // cópia ordenada por id (busca binária)
    private HashMap<Integer, Produto> mapaId = new HashMap<Integer, Produto>();
    private HashMap<String, List<Produto>> mapaCategoria = new HashMap<String, List<Produto>>();

    private String tempo = "-"; // texto do tempo da última operação

    public ArrayList<Produto> getLista() {
        return lista;
    }

    public String getTempo() {
        return tempo;
    }

    // lê o arquivo e monta a lista, a cópia por id e os HashMaps
    public boolean carregar(String nomeArquivo) {
        ArrayList<Produto> nova = new ArrayList<Produto>();
        if (!Utilidades.carregarArquivoEmLista(nomeArquivo, nova)) {
            return false;
        }
        lista = nova;

        listaPorId = new ArrayList<Produto>(lista);
        Ordenador.mergeSort(listaPorId, Ordenador.ID);

        long ini = System.nanoTime();
        mapaId = Buscador.montarMapaId(lista);
        long t = System.nanoTime() - ini;
        mapaCategoria = Buscador.montarMapaCategoria(lista);

        tempo = lista.size() + " produtos carregados | construção do HashMap (id): " + Utilidades.formatar(t);
        return true;
    }

    public boolean exportar(String nomeArquivo) {
        return Utilidades.salvarListaEmArquivo(nomeArquivo, lista);
    }

    // campo: 0 = nome, 1 = preço | algoritmo: 0 = Bubble Sort, 1 = Merge Sort
    // retorna false se o Bubble Sort passou de 2 minutos
    public boolean ordenar(int campo, int algoritmo) {
        boolean concluido = true;
        long ini = System.nanoTime();
        if (algoritmo == 0) {
            concluido = Ordenador.bubbleSort(lista, campo, LIMITE_2MIN);
        } else {
            Ordenador.mergeSort(lista, campo);
        }
        long t = System.nanoTime() - ini;

        if (concluido) {
            tempo = "ordenação em " + Utilidades.formatar(t);
        } else {
            tempo = "não concluído (> 2 min)";
        }
        return concluido;
    }

    // tecnica: 0 = linear, 1 = binária, 2 = HashMap
    public ArrayList<Produto> buscarPorId(int tecnica, int id) {
        Produto resultado = null;
        long ini = System.nanoTime();
        for (int i = 0; i < REPETICOES; i++) {
            if (tecnica == 0) {
                resultado = Buscador.buscaLinear(lista, id);
            } else if (tecnica == 1) {
                resultado = Buscador.buscaBinaria(listaPorId, id);
            } else {
                resultado = Buscador.buscaHash(mapaId, id);
            }
        }
        long media = (System.nanoTime() - ini) / REPETICOES;

        tempo = "busca por id (média de " + REPETICOES + "): " + Utilidades.formatar(media);
        ArrayList<Produto> encontrados = new ArrayList<Produto>();
        if (resultado != null) {
            encontrados.add(resultado);
        } else {
            tempo = tempo + " | não encontrado";
        }
        return encontrados;
    }

    public List<Produto> buscarPorCategoria(String categoria) {
        List<Produto> resultado = null;
        long ini = System.nanoTime();
        for (int i = 0; i < REPETICOES; i++) {
            resultado = Buscador.buscaCategoria(mapaCategoria, categoria);
        }
        long media = (System.nanoTime() - ini) / REPETICOES;

        if (resultado == null) {
            resultado = new ArrayList<Produto>();
        }
        tempo = "busca por categoria (média de " + REPETICOES + "): " + Utilidades.formatar(media)
                + " | " + resultado.size() + " produtos";
        return resultado;
    }

    public boolean gerarRelatorio(String nomeArquivo) {
        return Relatorio.gerar(nomeArquivo);
    }
}
