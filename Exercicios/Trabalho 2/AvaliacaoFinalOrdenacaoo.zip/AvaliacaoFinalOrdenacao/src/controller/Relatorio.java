package controller;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.HashMap;
import model.Buscador;
import model.Ordenador;
import model.Produto;
import util.Utilidades;

public class Relatorio {

    private static final int REPETICOES = 1000;
    private static final long LIMITE_2MIN = 120L * 1000000000L;

    public static boolean gerar(String nomeArquivo) {
        String[] arquivos = {"produtos_1000.txt", "produtos_10000.txt", "produtos_50000.txt"};
        String[] operacoes = {"Ordenação simples (por preço)", "Ordenação eficiente (por preço)",
            "Busca linear por id (média)", "Busca binária por id (média)",
            "Busca por HashMap (média)", "Construção do HashMap"};

        // tempos[linha da tabela][coluna: 1.000, 10.000, 50.000]
        String[][] tempos = new String[6][3];

        for (int a = 0; a < 3; a++) {
            ArrayList<Produto> base = new ArrayList<Produto>();
            if (!Utilidades.carregarArquivoEmLista(arquivos[a], base)) {
                return false;
            }
            long t;

            // 0 - ordenação simples
            ArrayList<Produto> copia = new ArrayList<Produto>(base);
            t = System.nanoTime();
            boolean concluiu = Ordenador.bubbleSort(copia, Ordenador.PRECO, LIMITE_2MIN);
            t = System.nanoTime() - t;
            tempos[0][a] = concluiu ? Utilidades.formatar(t) : "não concluído (> 2 min)";

            // 1 - ordenação eficiente
            copia = new ArrayList<Produto>(base);
            t = System.nanoTime();
            Ordenador.mergeSort(copia, Ordenador.PRECO);
            t = System.nanoTime() - t;
            tempos[1][a] = Utilidades.formatar(t);

            // lista ordenada por id (para a busca binária)
            ArrayList<Produto> porId = new ArrayList<Produto>(base);
            Ordenador.mergeSort(porId, Ordenador.ID);
            int id = base.get(base.size() / 2).getId();

            // 2 - busca linear
            t = System.nanoTime();
            for (int i = 0; i < REPETICOES; i++) {
                Buscador.buscaLinear(base, id);
            }
            tempos[2][a] = Utilidades.formatar((System.nanoTime() - t) / REPETICOES);

            // 3 - busca binária
            t = System.nanoTime();
            for (int i = 0; i < REPETICOES; i++) {
                Buscador.buscaBinaria(porId, id);
            }
            tempos[3][a] = Utilidades.formatar((System.nanoTime() - t) / REPETICOES);

            // 5 - construção do HashMap
            t = System.nanoTime();
            HashMap<Integer, Produto> mapa = Buscador.montarMapaId(base);
            tempos[5][a] = Utilidades.formatar(System.nanoTime() - t);

            // 4 - busca por HashMap
            t = System.nanoTime();
            for (int i = 0; i < REPETICOES; i++) {
                Buscador.buscaHash(mapa, id);
            }
            tempos[4][a] = Utilidades.formatar((System.nanoTime() - t) / REPETICOES);
        }

        try {
            BufferedWriter escritor = new BufferedWriter(new FileWriter(nomeArquivo));
            escritor.write("RELATÓRIO DE TEMPOS\n\n");
            escritor.write(String.format("%-35s | %-26s | %-26s | %-26s\n", "Operação", "1.000", "10.000", "50.000"));
            for (int i = 0; i < operacoes.length; i++) {
                escritor.write(String.format("%-35s | %-26s | %-26s | %-26s\n",
                        operacoes[i], tempos[i][0], tempos[i][1], tempos[i][2]));
            }
            escritor.write("\nAnálise:\n");
            escritor.write("(escreva aqui, em até 5 linhas, qual busca foi mais rápida e por quê,\n");
            escritor.write("e quando vale pagar o custo de construir o HashMap)\n");
            escritor.close();
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
