/*
 * Trabalho Prático - Pesquisa e Ordenação (UFN)
 * Autor: Guilherme Carlin Gonsalves
 * Turma: ______
 */
package view;

public class AvaliacaoFinalOrdenacao {

    public static void main(String[] args) {
        // visual Nimbus (botões cinza simples)
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            ex.printStackTrace();
        }

        java.awt.EventQueue.invokeLater(() -> new TelaPrincipal().setVisible(true));
    }
}
