package model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Buscador {

    // busca linear por id
    public static Produto buscaLinear(List<Produto> lista, int id) {
        for (int i = 0; i < lista.size(); i++) {
            if (lista.get(i).getId() == id) {
                return lista.get(i);
            }
        }
        return null;
    }

    // busca binaria por id - a lista TEM que estar ordenada por id
    public static Produto buscaBinaria(List<Produto> listaOrdenadaPorId, int id) {
        int ini = 0;
        int fim = listaOrdenadaPorId.size() - 1;
        while (ini <= fim) {
            int meio = (ini + fim) / 2;
            Produto p = listaOrdenadaPorId.get(meio);
            if (p.getId() == id) {
                return p;
            } else if (p.getId() < id) {
                ini = meio + 1;
            } else {
                fim = meio - 1;
            }
        }
        return null;
    }

    // HashMap<id, Produto>
    public static HashMap<Integer, Produto> montarMapaId(List<Produto> lista) {
        HashMap<Integer, Produto> mapa = new HashMap<Integer, Produto>();
        for (Produto p : lista) {
            mapa.put(p.getId(), p);
        }
        return mapa;
    }

    // HashMap<categoria, lista de produtos da categoria>
    public static HashMap<String, List<Produto>> montarMapaCategoria(List<Produto> lista) {
        HashMap<String, List<Produto>> mapa = new HashMap<String, List<Produto>>();
        for (Produto p : lista) {
            if (!mapa.containsKey(p.getCategoria().toLowerCase())) {
                mapa.put(p.getCategoria().toLowerCase(), new ArrayList<Produto>());
            }
            mapa.get(p.getCategoria().toLowerCase()).add(p);
        }
        return mapa;
    }

    // busca por id usando o HashMap
    public static Produto buscaHash(HashMap<Integer, Produto> mapa, int id) {
        return mapa.get(id);
    }

    // busca por categoria usando o HashMap (sem diferenciar maiúscula de minúscula)
    public static List<Produto> buscaCategoria(HashMap<String, List<Produto>> mapa, String categoria) {
        return mapa.get(categoria.toLowerCase());
    }
}
