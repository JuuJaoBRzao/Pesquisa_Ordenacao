package model;

import java.util.List;

public class Ordenador {

    // campos de ordenacao (mesma ordem do combo da tela: Nome = 0, Preço = 1)
    public static final int NOME = 0;
    public static final int PRECO = 1;
    public static final int ID = 2;

    // retorna > 0 se a for maior que b no campo escolhido
    private static int comparar(Produto a, Produto b, int campo) {
        if (campo == NOME) {
            return a.getNome().compareToIgnoreCase(b.getNome());
        } else if (campo == PRECO) {
            return Double.compare(a.getPreco(), b.getPreco());
        } else {
            return Integer.compare(a.getId(), b.getId());
        }
    }

    // ---------- Bubble Sort (simples) ----------
    // retorna false se passou do limite de tempo (nao concluido)
    public static boolean bubbleSort(List<Produto> lista, int campo, long limiteNanos) {
        long inicio = System.nanoTime();
        int n = lista.size();
        for (int i = 0; i < n - 1; i++) {
            boolean trocou = false;
            for (int j = 0; j < n - 1 - i; j++) {
                if (comparar(lista.get(j), lista.get(j + 1), campo) > 0) {
                    Produto aux = lista.get(j);
                    lista.set(j, lista.get(j + 1));
                    lista.set(j + 1, aux);
                    trocou = true;
                }
            }
            if (!trocou) {
                break;
            }
            if (System.nanoTime() - inicio > limiteNanos) {
                return false;
            }
        }
        return true;
    }

    // ---------- Merge Sort (eficiente) ----------
    public static void mergeSort(List<Produto> lista, int campo) {
        if (lista.size() < 2) {
            return;
        }
        Produto[] v = lista.toArray(new Produto[0]);
        Produto[] aux = new Produto[v.length];
        mergeSort(v, aux, 0, v.length - 1, campo);
        for (int i = 0; i < v.length; i++) {
            lista.set(i, v[i]);
        }
    }

    private static void mergeSort(Produto[] v, Produto[] aux, int ini, int fim, int campo) {
        if (ini >= fim) {
            return;
        }
        int meio = (ini + fim) / 2;
        mergeSort(v, aux, ini, meio, campo);
        mergeSort(v, aux, meio + 1, fim, campo);

        int i = ini;
        int j = meio + 1;
        int k = ini;
        while (i <= meio && j <= fim) {
            if (comparar(v[i], v[j], campo) <= 0) {
                aux[k++] = v[i++];
            } else {
                aux[k++] = v[j++];
            }
        }
        while (i <= meio) {
            aux[k++] = v[i++];
        }
        while (j <= fim) {
            aux[k++] = v[j++];
        }
        for (k = ini; k <= fim; k++) {
            v[k] = aux[k];
        }
    }
}
