package util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import model.Produto;

public class Utilidades {

    public static boolean carregarArquivoEmLista(String nomeArquivo, ArrayList<Produto> lista) {
        try {
            BufferedReader leitor = new BufferedReader(new FileReader(nomeArquivo));
            String linha = leitor.readLine(); // cabeçalho, ignora
            String dados[];
            while ((linha = leitor.readLine()) != null) {
                dados = linha.split(";");
                Produto p = new Produto(Integer.parseInt(dados[0]), dados[1], dados[2],
                        Double.parseDouble(dados[3]), Integer.parseInt(dados[4]));
                lista.add(p);
            }
            leitor.close();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean salvarListaEmArquivo(String nomeArquivo, ArrayList<Produto> lista) {
        try {
            BufferedWriter escritor = new BufferedWriter(new FileWriter(nomeArquivo));
            escritor.write("id;nome;categoria;preco;estoque\n");
            for (Produto p : lista) {
                escritor.write(p.getId() + ";" + p.getNome() + ";" + p.getCategoria() + ";"
                        + p.getPreco() + ";" + p.getEstoque() + "\n");
            }
            escritor.close();
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
