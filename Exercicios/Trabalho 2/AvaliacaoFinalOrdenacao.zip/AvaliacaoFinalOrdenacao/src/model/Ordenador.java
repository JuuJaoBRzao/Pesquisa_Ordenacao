package model;

import java.util.Comparator;
import java.util.List;

public class Ordenador {

	// ---------- Comparators ----------
	public Comparator<Produto> porNome() {
		return new Comparator<Produto>() {
			public int compare(Produto a, Produto b) {
				return a.getNome().compareToIgnoreCase(b.getNome());
			}
		};
	}

	public Comparator<Produto> porPreco() {
		return new Comparator<Produto>() {
			public int compare(Produto a, Produto b) {
				return Double.compare(a.getPreco(), b.getPreco());
			}
		};
	}

	public Comparator<Produto> porId() {
		return new Comparator<Produto>() {
			public int compare(Produto a, Produto b) {
				return Integer.compare(a.getId(), b.getId());
			}
		};
	}

	// ---------- Bubble Sort (simples) ----------
	// retorna false se passou do limite de tempo (nao concluido)
	public boolean bubbleSort(List<Produto> lista, Comparator<Produto> comp, long limiteNanos) {
		long inicio = System.nanoTime();
		int n = lista.size();
		for (int i = 0; i < n - 1; i++) {
			boolean trocou = false;
			for (int j = 0; j < n - 1 - i; j++) {
				if (comp.compare(lista.get(j), lista.get(j + 1)) > 0) {
					Produto aux = lista.get(j);
					lista.set(j, lista.get(j + 1));
					lista.set(j + 1, aux);
					trocou = true;
				}
			}
			if (!trocou) {
				break;
			}
			if (System.nanoTime() - inicio > limiteNanos) {
				return false;
			}
		}
		return true;
	}

	// ---------- Merge Sort (eficiente) ----------
	public void mergeSort(List<Produto> lista, Comparator<Produto> comp) {
		if (lista.size() < 2) {
			return;
		}
		Produto[] v = lista.toArray(new Produto[0]);
		Produto[] aux = new Produto[v.length];
		mergeSort(v, aux, 0, v.length - 1, comp);
		for (int i = 0; i < v.length; i++) {
			lista.set(i, v[i]);
		}
	}

	private void mergeSort(Produto[] v, Produto[] aux, int ini, int fim, Comparator<Produto> comp) {
		if (ini >= fim) {
			return;
		}
		int meio = (ini + fim) / 2;
		mergeSort(v, aux, ini, meio, comp);
		mergeSort(v, aux, meio + 1, fim, comp);

		int i = ini;
		int j = meio + 1;
		int k = ini;
		while (i <= meio && j <= fim) {
			if (comp.compare(v[i], v[j]) <= 0) {
				aux[k++] = v[i++];
			} else {
				aux[k++] = v[j++];
			}
		}
		while (i <= meio) {
			aux[k++] = v[i++];
		}
		while (j <= fim) {
			aux[k++] = v[j++];
		}
		for (k = ini; k <= fim; k++) {
			v[k] = aux[k];
		}
	}
}