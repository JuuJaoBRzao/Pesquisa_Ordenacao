/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package servidor.util;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import servidor.model.Sessao;

/**
 *
 * @author laboratorio
 */
public class Utilidades {

    public static boolean carregarArquivoEmHashMap(String nomeArquivo, HashMap<String, Sessao> sessoes, StringBuilder dadosSessoes) {
        try {
            FileReader procurador;
            procurador = new FileReader(nomeArquivo);
            //colocar o conteudo do arquivo na variavel dadosSessoes
            Path caminho = Paths.get(nomeArquivo);
            try{
                dadosSessoes.append(Files.readString(caminho));
            } catch (IOException e){
                return false;
            }
            
            //colocar o conteudo do arquivo no HashMap sessoes
            BufferedReader leitor = new BufferedReader(procurador);
            String linha;
            String dadosLinha[];
            Sessao sessao;
            do {
                linha = leitor.readLine();
                dadosLinha = linha.split(";");
                sessao = new Sessao (dadosLinha[0], dadosLinha [1]);
                sessoes.put(sessao.numeroCelular, sessao);            
            } while (linha != null);
            leitor.close();
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
